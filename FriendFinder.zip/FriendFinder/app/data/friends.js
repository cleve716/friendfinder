var listFriends = [
    {
      name: "Nikola Tesla",
      photo: "https://images2.minutemediacdn.com/image/upload/c_crop,h_842,w_1500,x_0,y_264/f_auto,q_auto,w_1100/v1555006688/shape/mentalfloss/tesla_circa_1890.jpg",
      scores: [
        "5",
        "1",
        "4",
        "4",
        "5",
        "1",
        "2",
        "5",
        "4",
        "1"
      ]
    },
    {
      name: "Thomas Edison",
      photo: "https://www.onthisday.com/images/people/thomas-edison-medium.jpg",
      scores: [
        "4",
        "2",
        "5",
        "1",
        "3",
        "2",
        "2",
        "1",
        "3",
        "2"
      ]
    },
    {
      name: "Robert M. Pirsig",
      photo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/85/Zen_motorcycle.jpg/220px-Zen_motorcycle.jpg",
      scores: [
        "5",
        "2",
        "2",
        "2",
        "4",
        "1",
        "3",
        "2",
        "5",
        "5"
      ]
    },
    {
      name: "David Lean",
      photo: "https://www.cliohistory.org/fileadmin/_processed_/9/e/csm_2-Movie_421c392105.jpg",
      scores: [
        "3",
        "3",
        "4",
        "2",
        "2",
        "1",
        "3",
        "2",
        "2",
        "3"
      ]
    },
    {
      name: "Diane Lane",
      photo: "http://www.thejewelleryeditor.com/media/images_thumbnails/filer_public_thumbnails/filer_public/7b/d7/7bd7f5d7-6c9e-4244-af40-c6b5e042c9c0/diane_lane_wearing_harry_kotlar_red_carpet_jewelry.jpg__1536x0_q75_crop-scale_subsampling-2_upscale-false.jpg",
      scores: [
        "4",
        "3",
        "4",
        "1",
        "5",
        "2",
        "5",
        "3",
        "1",
        "4"
      ]
    },
    {
      name: "Jennifer Connelly",
      photo: "https://m.media-amazon.com/images/M/MV5BOTczNTgzODYyMF5BMl5BanBnXkFtZTcwNjk4ODk4Mw@@._V1_UY317_CR12,0,214,317_AL_.jpg",
      scores: [
        "4",
        "4",
        "2",
        "3",
        "2",
        "2",
        "3",
        "2",
        "4",
        "5"
      ]
    }
  
  ];
  
  module.exports = listFriends;
  